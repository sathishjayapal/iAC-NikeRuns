import json
import logging
import os

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

rds = boto3.client("rds")
ec2 = boto3.client("ec2")



def _stop_db(cluster_identifier: str):
    logger.info("Stopping DB cluster %s", cluster_identifier)
    rds.stop_db_cluster(DBClusterIdentifier=cluster_identifier)



def _block_access(security_group_id: str):
    logger.info("Revoking ingress rules for security group %s", security_group_id)
    response = ec2.describe_security_groups(GroupIds=[security_group_id])
    ingress_rules = response["SecurityGroups"][0].get("IpPermissions", [])

    if ingress_rules:
        ec2.revoke_security_group_ingress(GroupId=security_group_id, IpPermissions=ingress_rules)



def handler(event, context):
    logger.info("Received event: %s", json.dumps(event))

    shutdown_mode = os.environ["SHUTDOWN_MODE"]
    cluster_identifier = os.environ["CLUSTER_IDENTIFIER"]
    security_group_id = os.environ["SECURITY_GROUP_ID"]

    if shutdown_mode == "stop_db":
        _stop_db(cluster_identifier)
    elif shutdown_mode == "block_access":
        _block_access(security_group_id)
    else:
        raise ValueError(f"Unsupported shutdown mode: {shutdown_mode}")

    return {"status": "ok", "shutdown_mode": shutdown_mode}
